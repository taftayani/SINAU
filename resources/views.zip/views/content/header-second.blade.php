<div class="navbar-fixed">
        <nav class="transparent-header">
          <div class="nav-wrapper">
            <a href="{{ route('survey.index') }}" class="brand-logo"><img src="../img/logo/bLogo.png" alt=""></a>
          </div>
        </nav>
 </div>