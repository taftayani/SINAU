
<footer class="page-footer footer-sec">
        <div class="container">
          <div class="row">
            <div class="col l12 s12 center">
                <a href="{{ route('survey.index') }}" class="brand-logo" > <img src="../img/Logo/logo.png" alt=""class="logo"></a>
                <p><a href=""  class="link-footer">SINAU OFFLINE</a>  - <a href="{{route('faq')}}"  class="link-footer"> FAQ </a>  - <a href=""  class="link-footer">SINAU ONNLINE</a> - <a href=""  class="link-footer">PERATURAN</a></p>
            </div>
            <div class="col l12 s12 center">
                <h5 class="white-text">Ikuti Kami di</h5>
          <div class="row">
                 <div class="col-2">
                    <i class="fa fa-linkedin-square" aria-hidden="true"><a class="white-text" href="https://www.nkedin.com/authwall?trk=bf&trkInfo=AQGYUUyr2s7HwgAAAWAmBORYv0B7veMTwryqXjMYbu1u-D9bWYPEjffw8vnsEvUm89RR2JTyqLtv5XX850WqmZJ_YD2BpHIBiN-SwNiKQ4GMWartfWC14XkDW8T1XZsCGUz6Fcg=&originalReferer=&sessionRedirect=https%3A%2F%2Fwww.nkedin.com%2Fcompany%2Fsinauyo%2F">linkedIn Sinau Yo</a></i>
                 </div>
                 <div class="col-2">
                    <i class="fa fa-facebook" aria-hidden="true"><a class="white-text" href="https://www.nkedin.com/authwall?trk=bf&trkInfo=AQGYUUyr2s7HwgAAAWAmBORYv0B7veMTwryqXjMYbu1u-D9bWYPEjffw8vnsEvUm89RR2JTyqLtv5XX850WqmZJ_YD2BpHIBiN-SwNiKQ4GMWartfWC14XkDW8T1XZsCGUz6Fcg=&originalReferer=&sessionRedirect=https%3A%2F%2Fwww.nkedin.com%2Fcompany%2Fsinauyo%2F">Facebook Sinau Yo</a></i>
                 </div>
                 <div class="col-2">
                    <i class="fa fa-instagram" aria-hidden="true"><a class="white-text" href="https://www.nkedin.com/authwall?trk=bf&trkInfo=AQGYUUyr2s7HwgAAAWAmBORYv0B7veMTwryqXjMYbu1u-D9bWYPEjffw8vnsEvUm89RR2JTyqLtv5XX850WqmZJ_YD2BpHIBiN-SwNiKQ4GMWartfWC14XkDW8T1XZsCGUz6Fcg=&originalReferer=&sessionRedirect=https%3A%2F%2Fwww.nkedin.com%2Fcompany%2Fsinauyo%2F">Instagram Sinau Yo</a></i>
                 </div>
          </div>
            </div>
          </div>
        </div>
        <div class="footer-copyright">
          <div class="container center">
          © SinauYo! 2017 All rights reserved
          </div>
        </div>
      </footer>
