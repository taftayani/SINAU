@extends('content.master2')
@section('content')
   @include('component.UserData.ConfirmData')
@endsection