@extends('content.master2')
@section('content')
    @include('component.AfterLogin.ChooseTeacher');
@endsection