<div class="container-fluid rows-third-profile">
    <div class="row"> 
      <div class="col xl12">
        <h1 class="header-profile-second">Fitur</h1>
      </div>
    </div>

    <div class="row rows-column-fitur">
        <div class="col xl5" id="img-study">
            <div class="row">
                <h1 class="center header-fitur">SINAU OFFLINE</h1>
            </div>
            <div class="row rows-teach">
                <div class="col xl6 column-devider-fitur">
                    <h5 class="center header-second-fitur">Pengajar Tersedia</h5>
                </div>
                <div class="col xl6">
                  <h5 class="center header-second-fitur">65</h5>
              </div>
            </div>

            <div class="row center">
            <button class="btn-fitur"> <a href="{{route('name_teacher')}}" class="link-fitur">Lihat Pengajar</a> </button>
            </div>

        </div>
        <div class="col xl5" id="img-book">
          <div class="row">
              <h1 class="center header-fitur">SINAU BOOK</h1>
          </div>
          <div class="row rows-teach">
              <div class="col xl6 column-devider-fitur">
                  <h5 class="center header-second-fitur">Buku Yang Tersedia</h5>
              </div>
              <div class="col xl6">
                <h5 class="center header-second-fitur">65</h5>
            </div>
          </div>

          <div class="row center">
              <button class="btn-fitur"><a href="" class="link-fitur">Lihat Buku</a></button>
          </div>

      </div>
    </div>
</div>