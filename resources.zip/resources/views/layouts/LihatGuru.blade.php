@extends('content.master2')
@section('content')
    @include('component.AfterLogin.ListTeacher')
@endsection
